/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ciclo4.ciclo4.Modelo;

/**
 *
 * @author calix
 */
public class Message {
    public String Textmessage;

    public Message() {
    }

    public Message(String message) {
        this.Textmessage = message;
    }

    public String getMessage() {
        return Textmessage;
    }

    public void setMessage(String message) {
        this.Textmessage = message;
    }
    
}
